$('#confirm-reset-practice-lab').click(function() {
    $('#reset-practice-lab-modal').modal('hide');
    window.location.href = "/reset.php";
});


var helpers = $('#helpers');
var prevHelperId = null;
var helperControls = helpers.find('li');
var helperCollapsibles = helpers.find('.collapse');

helperControls.on('click', collapse);

function collapse() {
    helperCollapsibles.css('display', 'none');
    if (prevHelperId === this.id && this.className === 'active') {
        helperControls.removeClass('active');
        return;
    }
    $('#' + this.id + '-collapsible').slideDown();
    helperControls.removeClass('active');
    this.className = 'active';
    prevHelperId = this.id;
}

var menu = $('.menu-container');

if (typeof localStorage !== 'undefined') {
    var preferences = {
        'nav': true
    };
    var userLocalPreferences = localStorage.getItem('userLocalPreferences');
    if (userLocalPreferences) {
        userLocalPreferences = JSON.parse(userLocalPreferences);
        if (userLocalPreferences.nav) {
            menu.css('display', 'table-cell');
        }
    }

    var warningShown = false;
    localStorage.setItem('last_visited_at', (new Date()).getTime().toString());

    function inactivity_alert() {
        warningShown = true;
        alert("You've been idle for too long. You'll now be redirected to Internshala Trainings.");
        window.location.href = 'https://trainings.internshala.com/content/hacking';
    }

    setInterval(function() {
        var old = parseInt(localStorage.getItem('last_visited_at')) || 0;
        if ((new Date()).getTime() - old >= 30 * 60 * 1000 && !warningShown) {
            inactivity_alert();
        }
    }, 1000);
}

function navbarToggle() {
    if (menu.css('display') == 'none') {
        menu.css('display', 'table-cell');
        if (typeof localStorage !== 'undefined') {
            preferences.nav = true;
            localStorage.setItem('userLocalPreferences', JSON.stringify(preferences));
        }
    } else {
        menu.css('display', 'none');
        if (typeof localStorage !== 'undefined') {
            preferences.nav = false;
            localStorage.setItem('userLocalPreferences', JSON.stringify(preferences));
        }
    }
}

$('.navbar-toggle').on('click dblclick', navbarToggle);